import { useState } from 'react';
import type { WorkflowExecution } from '@/types/workflow';
import type { ApiConfigField, KnowledgeBaseDocument, TenantUser, ValidationIssue } from '@/lib/api/types';
import { Zap } from 'lucide-react';
import { NodeConfigPanel } from './NodeConfigPanel';
import type { SelectedNodeInfo } from '@/pages/Index';
import type { ExecutionMode } from '@/hooks/useWorkflowExecution';
import { StepRow, statusIcon } from './execution/StepRow';
import { ExecutionControls } from './execution/ExecutionControls';
import { WorkflowSettingsTab } from './execution/WorkflowSettingsTab';

interface ExecutionPanelProps {
  selectedNode?: SelectedNodeInfo | null;
  onDeselectNode?: () => void;
  onDeleteNode?: () => void;
  onConfigSave?: (config: Record<string, unknown>, name?: string) => void;
  apiConfigFields?: ApiConfigField[];
  nodeValidationIssues?: Map<string, ValidationIssue[]>;
  tenantUsers?: TenantUser[];
  kbDocuments?: KnowledgeBaseDocument[];
  execution?: WorkflowExecution | null;
  executionMode?: ExecutionMode;
  currentStepIndex?: number;
  onRunAll?: () => void;
  onStepForward?: () => void;
  onPause?: () => void;
  onResume?: () => void;
  onReset?: () => void;
}

export function ExecutionPanel({
  selectedNode,
  onDeselectNode,
  onDeleteNode,
  onConfigSave,
  apiConfigFields,
  nodeValidationIssues,
  tenantUsers = [],
  kbDocuments = [],
  execution,
  executionMode = 'idle',
  currentStepIndex = -1,
  onRunAll,
  onStepForward,
  onPause,
  onResume,
  onReset,
}: ExecutionPanelProps) {
  const [activeTab, setActiveTab] = useState<'execution' | 'configuration'>('execution');

  const effectiveTab = selectedNode ? 'configuration' : activeTab;
  const isRunning = executionMode === 'running';
  const isCompleted = executionMode === 'completed';

  return (
    <div className="w-[320px] h-full bg-background border-l border-border flex flex-col">
      {/* Tabs */}
      <div className="flex border-b border-border">
        <button
          onClick={() => { setActiveTab('configuration'); }}
          className={`flex-1 px-4 py-2.5 text-xs font-medium transition-colors ${
            effectiveTab === 'configuration' ? 'text-foreground border-b-2 border-primary' : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          {selectedNode ? 'Node Config' : 'Configuration'}
        </button>
        <button
          onClick={() => { setActiveTab('execution'); if (onDeselectNode) onDeselectNode(); }}
          className={`flex-1 px-4 py-2.5 text-xs font-medium transition-colors relative ${
            effectiveTab === 'execution' ? 'text-foreground border-b-2 border-primary' : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          Execution
          {isRunning && (
            <span className="absolute top-2 right-3 w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
          )}
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        {effectiveTab === 'configuration' && selectedNode ? (
          <NodeConfigPanel
            node={selectedNode}
            apiConfigFields={apiConfigFields}
            onClose={() => onDeselectNode?.()}
            onDelete={onDeleteNode}
            onConfigSave={onConfigSave}
            validationIssues={selectedNode ? nodeValidationIssues?.get(selectedNode.id) : undefined}
            tenantUsers={tenantUsers}
            kbDocuments={kbDocuments}
          />
        ) : effectiveTab === 'execution' ? (
          <div className="h-full overflow-y-auto p-3">
            <ExecutionControls
              executionMode={executionMode}
              execution={execution}
              onRunAll={onRunAll}
              onStepForward={onStepForward}
              onPause={onPause}
              onResume={onResume}
              onReset={onReset}
            />

            {/* Execution Header */}
            {execution && (
              <>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    {isCompleted ? statusIcon.success : isRunning ? statusIcon.running : statusIcon.idle}
                    <span className="text-xs font-medium text-foreground">Run #{execution.id.split('-')[1]?.slice(0, 6)}</span>
                  </div>
                  {execution.completedAt && (
                    <span className="text-[10px] text-muted-foreground font-mono">
                      {((new Date(execution.completedAt).getTime() - new Date(execution.startedAt).getTime()) / 1000).toFixed(1)}s
                    </span>
                  )}
                </div>

                {/* Steps */}
                <div className="space-y-0">
                  {execution.steps.map((step, i) => (
                    <StepRow key={step.id} step={step} isActive={i === currentStepIndex} />
                  ))}
                </div>
              </>
            )}

            {/* Empty state */}
            {!execution && (
              <div className="flex flex-col items-center justify-center h-48 text-center">
                <Zap className="h-8 w-8 text-muted-foreground/30 mb-3" />
                <p className="text-xs text-muted-foreground">No execution yet</p>
                <p className="text-[10px] text-muted-foreground/60 mt-1">Click "Run All" or "Step" to start</p>
              </div>
            )}
          </div>
        ) : (
          <WorkflowSettingsTab />
        )}
      </div>
    </div>
  );
}
