import { useState } from 'react';
import { CheckCircle2, XCircle, Clock, Loader2, ChevronDown } from 'lucide-react';
import type { ExecutionStep } from '@/types/workflow';
import { VariableTree } from './VariableTree';

// Status → icon map, shared by StepRow and the execution header.
export const statusIcon: Record<string, React.ReactNode> = {
  success: <CheckCircle2 className="h-3.5 w-3.5 text-success" />,
  failed: <XCircle className="h-3.5 w-3.5 text-destructive" />,
  running: <Loader2 className="h-3.5 w-3.5 text-primary animate-spin" />,
  waiting: <Clock className="h-3.5 w-3.5 text-warning" />,
  idle: <Clock className="h-3.5 w-3.5 text-muted-foreground" />,
};

// One step in the execution timeline; expands to show its output variables.
export function StepRow({ step, isActive }: { step: ExecutionStep; isActive?: boolean }) {
  const [expanded, setExpanded] = useState(false);

  // Auto-expand running step
  const shouldExpand = expanded || (step.status === 'running');

  return (
    <div className={`border-l-2 ml-2 pl-3 relative transition-colors ${
      isActive ? 'border-primary' : step.status === 'success' ? 'border-success/40' : 'border-border'
    }`}>
      <div className={`absolute -left-[5px] top-2.5 w-2 h-2 rounded-full transition-colors ${
        step.status === 'running' ? 'bg-primary animate-pulse' :
        step.status === 'success' ? 'bg-success' :
        step.status === 'failed' ? 'bg-destructive' : 'bg-border'
      }`} />
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full text-left py-2 group"
      >
        <div className="flex items-center gap-2">
          {statusIcon[step.status]}
          <span className="text-[10px] font-mono text-muted-foreground">[{step.timestamp}]</span>
          <span className="text-xs font-medium text-foreground flex-1 truncate">{step.nodeLabel}</span>
          {step.duration != null && step.status !== 'idle' && (
            <span className="text-[10px] text-muted-foreground">{step.duration}ms</span>
          )}
          <ChevronDown className={`h-3 w-3 text-muted-foreground transition-transform ${shouldExpand ? '' : '-rotate-90'}`} />
        </div>
        {step.message && step.status !== 'idle' && (
          <p className="text-[10px] text-muted-foreground mt-0.5 ml-5 truncate">{step.message}</p>
        )}
      </button>

      {shouldExpand && step.status !== 'idle' && (
        <div className="pb-2 ml-5">
          <div className="text-[10px] font-medium text-muted-foreground mb-1 uppercase tracking-wider">Variables</div>
          <div className="bg-muted/40 rounded-md p-2 border border-border/50">
            <VariableTree data={step.variables} />
          </div>
        </div>
      )}
    </div>
  );
}
